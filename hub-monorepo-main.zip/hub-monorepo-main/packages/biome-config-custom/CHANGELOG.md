# biome-config-custom

## 0.0.1

### Patch Changes

- 1e4482e: updated dependencies

## Generating a chronological feed

This example generates a chronological feed from a list of FIDs (For eg., the list of FIDs that a user
is following)

To run this example,
```bash
yarn install
yarn start
```

## Generating a profile page for a user

This example pulls together all of a user's profile data.

To run this example,
```bash
yarn install
yarn start
```

```bash
$> yarn start
yarn run v1.22.19
$ tsx index.ts
USER_DATA_TYPE_PFP
https://i.seadn.io/gae/sYAr036bd0bRpj7OX6B-F-MqLGznVkK3--DSneL_BT5GX4NZJ3Zu91PgjpD9-xuVJtHq0qirJfPZeMKrahz8Us2Tj_X8qdNPYC-imqs?w=500&auto=format

USER_DATA_TYPE_BIO
Technowatermelon. Elder Millenial. Building Farcaster.

nf.td/varun

USER_DATA_TYPE_DISPLAY
Varun Srinivasan

USER_DATA_TYPE_USERNAME
v

Done!
```
## Subscribing to Hub Events 

This example shows how to listen to the firehose of events emitted by the Hubs.

To run this example,
```bash
yarn install
yarn start
```



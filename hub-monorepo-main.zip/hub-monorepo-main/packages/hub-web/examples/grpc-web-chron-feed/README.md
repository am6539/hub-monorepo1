
**Deprecation Notice:**
grpc-web has been deprecated and is no longer supported. Please use the [HTTP API](../../README.md) instead. This original document has been kept only for historical reference.

## Generate a chronological feed

## Submitting messages to a Hub using Go lang

This Golang example generates and submits a message to the Hub. You will need a Signer for the user you are submitting a message on behalf of.

To run this example,
```bash
make generate
make build
./golang-submitmessage
```

## Generate a chronological feed

### Run locally

1. Clone the repo locally
2. Navigate to this folder with `cd packages/hub-nodejs/examples/chron-feed`
3. Run `yarn install` to install dependencies
4. Run `yarn start`

export default async () => {
  await globalThis._ANVIL_SHUTDOWN();
};

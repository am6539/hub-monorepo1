// List of bootstrap peers for mainnet
export const MAINNET_BOOTSTRAP_PEERS = [
  "/dns/hoyt.farcaster.xyz/tcp/2282",
  "/dns/lamia.farcaster.xyz/tcp/2282",
  "/dns/nemes.farcaster.xyz/tcp/2282",
  "/dns/bootstrap.neynar.com/tcp/2282",
];

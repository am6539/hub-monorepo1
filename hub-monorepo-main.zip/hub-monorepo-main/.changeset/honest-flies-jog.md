---
"@farcaster/hubble": minor
---

CLI tool for measuring sync health

---
"@farcaster/core": patch
"@farcaster/hubble": patch
---

fix: http endoint return not found instead of internal database error
